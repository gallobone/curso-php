<?php
//Footer
?>

			<div class="fader"></div>
			
			</div>
		<footer><!--insert footer html content--></footer>
	</body>
</html>