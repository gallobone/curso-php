<?php
//Footer
?>


			</div>
		<footer><!--insert footer html content--></footer>
	</body>
</html>