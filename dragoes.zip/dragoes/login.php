<?php 

include_once('includes/header.php');

$login = $_GET['login'];

?>

		
		<div class="container">
			<div class="row mt-5">
				<div class="col-12">
					<div class="box-form">

						<h1 class="terror-blue monoton">Login</h1><br/>

						<!--<div class="logo text-center"><img src="images/logo-dbfc.png"></div>-->

						<form id="formlogin" name="formlogin" action="validaLogin.php" method="post">

						  <div class="form-group">
						    <label for="username">Username</label>
						    <input type="text" class="form-control" id="username" placeholder="Username" name="login">
						  </div>
						  
						  <div class="form-group">
						    <label for="password">Password</label>
						    <input type="password" class="form-control" id="password" placeholder="Password" name="senha">
						  </div>

						  <!--<input type="button" name="" value="Login" id="bt_login" class="btn btn-primary">-->
						  <input type="submit" name="" value="Login" class="btn btn-primary">

						</form>
					</div>

					<div class="msg mt-5 nosifer">
						<?php if($login == 'false') : ?>
								<?= "<h3 class='red-blood'>LOGIN FAILED</h3><br/>";?>
						<?php elseif($login == 'no_session') : ?>
								<?= "<h3 class='strong-yellow'>Faça o Login</h3><br/>" ;?>
						<?php endif;?>
					</div>

				</div>
			</div>
		</div>
	
<?php include_once('includes/footer.php');?>