<?php

require_once('config.php');


echo "App Dragões";


//Testando conexão
//$obj = new Sql();



?>