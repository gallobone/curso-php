<?php

require_once('config.php');


$nome = $_GET['user'];
//$iduser = $_GET['iduser'];


if($nome == NULL){
	header("location: login.php?login=no_session");
}
else{

	$obj = new Jogadores();
	$lista_jogadores = $obj->getJogadores();
}




include_once('includes/header.php');

?>

	<div class="container">
		<div class="row">
			<div class="col-12 mt-5 mb-5">
				<h1 class="white frijole">Hello, Mr. <span class='welcome-msg nosifer terror-blue'><?= $nome; ?> !!!</span></h1>	
			</div>
		</div>

		<div>
			
		</div>
		
		<div class="d-none">
			<h2 class="nosifer strong-orange"><?= "Monster";  ?></h2>
			<h2 class="nosifer frijole dark-pinky "><?= "Terror";  ?></h2>
			<h2 class="nosifer creepster deep-purple"><?= "Ghost";  ?></h2>
			<h2 class="nosifer monoton strong-yellow"><?= "Vampire";  ?></h2>
			<h2 class="nosifer alfa-slab green-light"><?= "Darkness";  ?></h2>
			<h2 class="nosifer modak red-blood"><?= "Pirate";  ?></h2>
			<h2 class="nosifer anton strong-orange"><?= "Demon";  ?></h2>
			<h2 class="nosifer sigmar-one ghost-grey"><?= "Hell";  ?></h2>	
		</div>


		<section class="section-squadre mt-5">
			<div class="container pt-5">
				<div class="row boxes">
					<?php foreach($lista_jogadores as $row) :?>
						
						<div class="col-2 mt-4 mb-4 text-center">
							<h3 class="title-players anton"><?php echo utf8_encode($row['apelido']);?></h3>
							<img style="max-height:140px; max-width: 190px;" src="images/<?php echo $row['image_path'];?>.jpg">
						</div>

					<?php endforeach; ?>
				</div>
			</div>
		</section>
		

	</div>

<?php
	include_once('includes/footer.php');
?>