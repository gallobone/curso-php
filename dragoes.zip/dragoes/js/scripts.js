$(document).ready(function() {

	jQuery("#bt_login").on('click', function(){
		validaLogin();
	})


	$(document).bind('keypress', function(e) {
        if(e.keyCode==13){
             $('#bt_login').trigger('click');
         }
    });


	animateWelcomeMsg();



});

function animateWelcomeMsg(){
	jQuery(".welcome-msg").fadeIn(1500);
}


function validaLogin(){

	var login = jQuery("#username").val();
	var senha = jQuery("#password").val();

	jQuery.ajax({
	  url: 'http://localhost:9000/dragoes/validaLogin.php',
	  type: 'POST',
	  dataType: 'json',
	  data: {login: login, senha: senha},
	  
	  complete: function(xhr, textStatus) {
	    console.log("complete");
	  },
	  success: function(data, textStatus, xhr) {
	    //called when successful

	    jQuery.each(data, function(index, val) {
			console.log(index, val);
			var validaId = data[index].id;

			if(validaId > 0){
				alert("Seja Bem-vindo");
				window.location.href = "index.php";
			}
			else{
				alert("LOGIN INVÁLIDO");
			}

		});

	  },
	  error: function(xhr, textStatus, errorThrown) {
	  	console.log("0");
	  	console.log(textStatus);
	  	console.log(errorThrown);
	    //called when there is an error
	    alert("Login Inválido");
	  }
	});

	
}




